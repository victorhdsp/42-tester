#include "tests.h"

void test_ft_isalnum(void) {
    TEST_ASSERT_EQUAL(1, ft_isalnum('c'));
    TEST_ASSERT_EQUAL(1, ft_isalnum('1'));
    TEST_ASSERT_EQUAL(0, ft_isalnum('-'));
    TEST_ASSERT_EQUAL(1, ft_isalnum('B'));
    TEST_ASSERT_EQUAL(0, ft_isalnum('\0'));
    TEST_ASSERT_EQUAL(0, ft_isalnum('a' - 1));
	TEST_ASSERT_EQUAL(1, ft_isalnum('a'));
	TEST_ASSERT_EQUAL(0, ft_isalnum('z' + 1));
	TEST_ASSERT_EQUAL(1, ft_isalnum('z'));
	TEST_ASSERT_EQUAL(0, ft_isalnum('A' - 1));
	TEST_ASSERT_EQUAL(1, ft_isalnum('A'));
	TEST_ASSERT_EQUAL(0, ft_isalnum('Z' + 1));
	TEST_ASSERT_EQUAL(1, ft_isalnum('Z'));
	TEST_ASSERT_EQUAL(0, ft_isalnum('0' - 1));
	TEST_ASSERT_EQUAL(1, ft_isalnum('0'));
	TEST_ASSERT_EQUAL(0, ft_isalnum('9' + 1));
	TEST_ASSERT_EQUAL(1, ft_isalnum('9'));
}