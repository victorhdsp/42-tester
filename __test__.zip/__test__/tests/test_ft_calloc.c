#include "tests.h"

void test_ft_calloc(void) {
    char    *test1;
    char    *expected1;

    expected1 = (char *)calloc(10, sizeof(char));
    test1 = (char *)ft_calloc(10, sizeof(char));
    
    TEST_ASSERT_EQUAL(expected1[0], test1[0]);

    char * p = ft_calloc(2, 2);
    p[0] = '4';
	TEST_ASSERT_EQUAL_STRING(p, "4");
	TEST_ASSERT(strlen(p) == 1);
	TEST_ASSERT_EQUAL(ft_calloc(SIZE_MAX, SIZE_MAX), NULL);
	TEST_ASSERT_EQUAL(ft_calloc(INT_MAX, INT_MAX), NULL);
	TEST_ASSERT_EQUAL(ft_calloc(INT_MIN, INT_MIN), NULL);
	p = ft_calloc(0, 0);
	TEST_ASSERT_EQUAL(p, NULL);
	p = ft_calloc(0, 5);
	TEST_ASSERT_EQUAL(p, NULL);
	p = ft_calloc(5, 0);
	TEST_ASSERT_EQUAL(p, NULL);
	TEST_ASSERT_EQUAL(ft_calloc(-5, -5), NULL);
	p = ft_calloc(0, -5);
	TEST_ASSERT_EQUAL(p, NULL);
	p = ft_calloc(-5, 0);
	TEST_ASSERT_EQUAL(p, NULL);
	TEST_ASSERT_EQUAL(ft_calloc(3, -5), NULL);
	TEST_ASSERT_EQUAL(ft_calloc(-5, 3), NULL);
}