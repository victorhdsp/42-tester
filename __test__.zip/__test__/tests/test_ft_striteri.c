#include "tests.h"

void ft_test2(unsigned int i, char *c)
{
   if (*c + i < 127)
        *c += i;
}
void test_ft_striteri(void) {
    char result[8] = "adoleta";

    ft_striteri(result, ft_test2);
    TEST_ASSERT_EQUAL_STRING("aeqoiyg", result);

    char s1[] = "";
    ft_striteri(s1, ft_test2);
    TEST_ASSERT(strcmp(s1, "") == '\0');

    char s2[] = "0";
    ft_striteri(s2, ft_test2);
    TEST_ASSERT(strcmp(s2, "0") == '\0');

    char s3[] = "0000000000";
    ft_striteri(s3, ft_test2);
    TEST_ASSERT(strcmp(s3, "0123456789") == '\0');
}