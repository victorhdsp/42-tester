#include "tests.h"

void test_ft_split(void) {
    char    **test1;
    char    **test2;

    test1 = ft_split("1,2,3,4,5,6,7,89\0", ',');
    TEST_ASSERT_EQUAL_STRING("1", test1[0]);
    TEST_ASSERT_EQUAL_STRING("2", test1[1]);
    TEST_ASSERT_EQUAL_STRING("3", test1[2]);
    TEST_ASSERT_EQUAL_STRING("4", test1[3]);
    TEST_ASSERT_EQUAL_STRING("5", test1[4]);
    TEST_ASSERT_EQUAL_STRING("89", test1[7]);
    test2 = ft_split("", ',');
    TEST_ASSERT_EQUAL_STRING(NULL, test2[0]);
    free(test1);
    free(test2);

    char **tab = ft_split("  tripouille  42  ", ' ');

    TEST_ASSERT_EQUAL_STRING(tab[0], "tripouille");
    TEST_ASSERT_EQUAL_STRING(tab[1], "42");
    TEST_ASSERT_EQUAL_STRING(tab[2], NULL);
	tab = ft_split("tripouille", 0);
    TEST_ASSERT_EQUAL_STRING(tab[0], "tripouille");
    TEST_ASSERT_EQUAL_STRING(tab[1], NULL);
	tab = ft_split("     ", ' ');
    TEST_ASSERT_EQUAL_STRING(tab[0], NULL);
	free(tab);

	tab = ft_split("", 0);
	TEST_ASSERT_EQUAL_STRING(tab[0], NULL);
	free(tab);

	tab = ft_split("chinimala", ' ');
	TEST_ASSERT_EQUAL_STRING(tab[0], "chinimala");
	TEST_ASSERT_EQUAL_STRING(tab[1], NULL);
	
	tab = ft_split("", ' ');
	TEST_ASSERT_EQUAL_STRING(tab[0], NULL);

	/* sguerra- */
	char *splitme = strdup("Tripouille");
	tab = ft_split(splitme, ' ');
	TEST_ASSERT_EQUAL_STRING(tab[0], "Tripouille");
	TEST_ASSERT_EQUAL_STRING(tab[1], NULL);
	free(splitme); 

	splitme = strdup("Tripouille ");
	tab = ft_split(splitme, ' ');
	TEST_ASSERT(strcmp(tab[0], "Tripouille") == '\0');
	TEST_ASSERT_EQUAL_STRING(tab[1], NULL);
	free(splitme); 

	splitme = strdup(" Tripouille");
	tab = ft_split(splitme, ' ');
	TEST_ASSERT(strcmp(tab[0], "Tripouille") == '\0');
	TEST_ASSERT(tab[1] == NULL);
	free(splitme); 

	splitme = strdup(" Tripouille ");
	tab = ft_split(splitme, ' ');
	TEST_ASSERT(strcmp(tab[0], "Tripouille") == '\0');
	TEST_ASSERT_EQUAL(strlen(tab[0]), strlen("Tripouille"));
	TEST_ASSERT(tab[1] == NULL);
	free(splitme); 

	/* wleite */
	splitme = strdup("--1-2--3---4----5-----42");
	tab = ft_split(splitme, '-');
	TEST_ASSERT(strcmp(tab[0], "1") == '\0');
	TEST_ASSERT_EQUAL(strlen(tab[0]), strlen("1"));

	TEST_ASSERT(strcmp(tab[1], "2") == '\0');
	TEST_ASSERT_EQUAL(strlen(tab[1]), strlen("2"));

	TEST_ASSERT(strcmp(tab[2], "3") == '\0');
	TEST_ASSERT_EQUAL(strlen(tab[2]), strlen("3"));

	TEST_ASSERT(strcmp(tab[3], "4") == '\0');
	TEST_ASSERT_EQUAL(strlen(tab[3]), strlen("4"));

	TEST_ASSERT(strcmp(tab[4], "5") == '\0');
	TEST_ASSERT_EQUAL(strlen(tab[4]), strlen("5"));

	TEST_ASSERT(strcmp(tab[5], "42") == '\0');
	TEST_ASSERT_EQUAL(strlen(tab[5]), strlen("42"));

	TEST_ASSERT(tab[6] == NULL);
    free(splitme); 
}