#include "tests.h"

void test_ft_lstadd_front(void) {
    t_list * l =  NULL;
	ft_lstadd_front(&l, ft_lstnew((void*)1));
	TEST_ASSERT_EQUAL(l->content, (void*)1);
	TEST_ASSERT_EQUAL(l->next, 0);

	ft_lstadd_front(&l, ft_lstnew((void*)2));
	TEST_ASSERT_EQUAL(l->content, (void*)2);
	TEST_ASSERT_EQUAL(((t_list *)l->next)->content, (void*)1);
	TEST_ASSERT_EQUAL(((t_list *)l->next)->next, 0);
}