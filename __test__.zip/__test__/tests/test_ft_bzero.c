#include "tests.h"

void test_ft_bzero(void) {
    char    expected[10];
    char    result[10];

    memset(expected, 'A', 9);
    ft_memset(result, 'A', 9);
    TEST_ASSERT_EQUAL_STRING(expected, result);

    bzero(expected, 9);
    ft_bzero(result, 9);
    TEST_ASSERT_EQUAL_STRING(expected, result);
}