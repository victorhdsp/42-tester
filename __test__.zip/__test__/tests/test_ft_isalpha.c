#include "tests.h"

void test_ft_isalpha(void) {
    TEST_ASSERT_EQUAL(1, ft_isalpha('c'));
    TEST_ASSERT_EQUAL(0, ft_isalpha('1'));
    TEST_ASSERT_EQUAL(0, ft_isalpha('-'));
    TEST_ASSERT_EQUAL(1, ft_isalpha('B'));
    TEST_ASSERT_EQUAL(0, ft_isalpha('\0'));
    TEST_ASSERT_EQUAL(0, ft_isalpha('a' - 1));
	TEST_ASSERT_EQUAL(1, ft_isalpha('a'));
	TEST_ASSERT_EQUAL(0, ft_isalpha('z' + 1));
	TEST_ASSERT_EQUAL(1, ft_isalpha('z'));
	TEST_ASSERT_EQUAL(0, ft_isalpha('A' - 1));
	TEST_ASSERT_EQUAL(1, ft_isalpha('A'));
	TEST_ASSERT_EQUAL(0, ft_isalpha('Z' + 1));
	TEST_ASSERT_EQUAL(1, ft_isalpha('Z'));
}