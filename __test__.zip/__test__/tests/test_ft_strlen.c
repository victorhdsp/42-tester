#include "tests.h"

void test_ft_strlen(void) {
    TEST_ASSERT_EQUAL(strlen("teste"), ft_strlen("teste"));
    TEST_ASSERT_EQUAL(strlen("Victor"), ft_strlen("Victor"));
    TEST_ASSERT_EQUAL(strlen("Ca ra m ba"), ft_strlen("Ca ra m ba"));
    TEST_ASSERT_EQUAL(strlen(""), ft_strlen(""));
    TEST_ASSERT_EQUAL(strlen("42 42 42"), ft_strlen("42 42 42"));
    TEST_ASSERT_EQUAL(strlen("@!L#k$T!@"), ft_strlen("@!L#k$T!@"));

    TEST_ASSERT(ft_strlen("123") == 3);
	TEST_ASSERT(ft_strlen("") == 0);
}