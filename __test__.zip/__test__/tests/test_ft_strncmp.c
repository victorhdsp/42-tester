#include "tests.h"

void test_ft_strncmp(void) {
    char    test1[9] = "abcdefg\0";
    char    test2[9] = "fffffff\0";

    TEST_ASSERT_EQUAL(strncmp(test1, test2, 6), ft_strncmp(test1, test2, 6));

    TEST_ASSERT(ft_strncmp("t", "", 0) == 0);
	TEST_ASSERT(ft_strncmp("1234", "1235", 3) == 0);
	TEST_ASSERT(ft_strncmp("1234", "1235", 4) < 0);
	TEST_ASSERT(ft_strncmp("1234", "1235", -1) < 0);
	TEST_ASSERT(ft_strncmp("", "", 42) == 0);
	TEST_ASSERT(ft_strncmp("Tripouille", "Tripouille", 42) == 0);
	TEST_ASSERT(ft_strncmp("Tripouille", "tripouille", 42) < 0);
	TEST_ASSERT(ft_strncmp("Tripouille", "TriPouille", 42) > 0);
	TEST_ASSERT(ft_strncmp("Tripouille", "TripouillE", 42) > 0);
	TEST_ASSERT(ft_strncmp("Tripouille", "TripouilleX", 42) < 0);
	TEST_ASSERT(ft_strncmp("Tripouille", "Tripouill", 42) > 0);
	TEST_ASSERT(ft_strncmp("", "1", 0) == 0);
	TEST_ASSERT(ft_strncmp("1", "", 0) == 0);
	TEST_ASSERT(ft_strncmp("", "1", 1) < 0);
	TEST_ASSERT(ft_strncmp("1", "", 1) > 0);
	TEST_ASSERT(ft_strncmp("", "", 1) == 0);
}