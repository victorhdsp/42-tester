#include "tests.h"

void test_ft_itoa(void) {
    int     tests[10] = {0, 1, -1, 42, INT_MAX, INT_MIN};
    int     i;

    i = 0;
    while (i < 6)
    {
        char    expected[20];
        char    *result;

        snprintf(expected, sizeof(expected), "%d", tests[i]);
        result = ft_itoa(tests[i]);
        TEST_ASSERT_EQUAL_STRING(expected, result);
        free(result);
        i++;
    }
}