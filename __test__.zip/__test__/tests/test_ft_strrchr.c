#include "tests.h"

void test_ft_strrchr(void) {
    char s[] = "tripouille";
	char s2[] = "ltripouiel";
	char s3[] = "";
	TEST_ASSERT(ft_strrchr(s, 't') == s);
	TEST_ASSERT(ft_strrchr(s, 'l') == s + 8);
	TEST_ASSERT(ft_strrchr(s2, 'l') == s2 + 9);
	TEST_ASSERT(ft_strrchr(s, 'z') == NULL);
	TEST_ASSERT_EQUAL_STRING(ft_strrchr(s, 0), s + strlen(s));
	TEST_ASSERT(ft_strrchr(s, 't' + 256) == s);
	char * empty = (char*)calloc(1, 1);
	TEST_ASSERT(ft_strrchr(empty, 'V') == NULL);
	TEST_ASSERT_EQUAL_STRING(ft_strrchr(s3, 0), s3);
}