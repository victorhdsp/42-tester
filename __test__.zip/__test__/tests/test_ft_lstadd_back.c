#include "tests.h"

void test_ft_lstadd_back(void) {
    t_list *lst1;
    t_list *lst2;
    t_list *lst3;

    lst1 = ft_lstnew((void *)"test1");
    lst2 = ft_lstnew((void *)"test2");
    lst3 = ft_lstnew((void *)"test3");
    ft_lstadd_front(&lst2, lst3);
    ft_lstadd_back(&lst2, lst1);
    TEST_ASSERT_EQUAL_STRING("test1", lst2->next->content);

	t_list * l =  NULL; t_list * l2 =  NULL;
	ft_lstadd_back(&l, ft_lstnew((void*)1));
	TEST_ASSERT_EQUAL(l->content, (void*)1);
	TEST_ASSERT_EQUAL(l->next, 0);

	ft_lstadd_back(&l, ft_lstnew((void*)2));
	TEST_ASSERT_EQUAL(l->content, (void*)1);
	TEST_ASSERT_EQUAL(((t_list *)(l->next))->content, (void*)2);
	TEST_ASSERT_EQUAL(((t_list *)(l->next))->next, 0);

	ft_lstadd_back(&l2, ft_lstnew((void*)3));
	ft_lstadd_back(&l2, ft_lstnew((void*)4));
	ft_lstadd_back(&l, l2);
	TEST_ASSERT_EQUAL(l->content, (void*)1);
	TEST_ASSERT_EQUAL(((t_list *)(l->next))->content, (void*)2);
	TEST_ASSERT_EQUAL(((t_list *)(((t_list *)(l->next))->next))->content, (void*)3);
	TEST_ASSERT_EQUAL(((t_list *)((t_list *)(((t_list *)(l->next))->next))->next)->content, (void*)4);
	TEST_ASSERT_EQUAL(((t_list *)((t_list *)(((t_list *)(l->next))->next))->next)->next, 0);
}