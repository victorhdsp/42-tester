#include "tests.h"

void test_ft_lstlast(void) {
    t_list * l =  NULL;
	TEST_ASSERT_EQUAL(ft_lstlast(l), 0);
	ft_lstadd_back(&l, ft_lstnew((void*)1));
	TEST_ASSERT_EQUAL(ft_lstlast(l)->content, (void*)1);
	ft_lstadd_back(&l, ft_lstnew((void*)2));
	TEST_ASSERT_EQUAL(ft_lstlast(l)->content, (void*)2);
	TEST_ASSERT_EQUAL(ft_lstlast(l)->next, 0);
}