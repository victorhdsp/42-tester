#include "tests.h"

void test_ft_isdigit(void) {
    TEST_ASSERT_EQUAL(0, ft_isdigit('c'));
    TEST_ASSERT_EQUAL(1, ft_isdigit('1'));
    TEST_ASSERT_EQUAL(0, ft_isdigit('-'));
    TEST_ASSERT_EQUAL(0, ft_isdigit('B'));
    TEST_ASSERT_EQUAL(0, ft_isdigit('\0'));
    TEST_ASSERT_EQUAL(0, ft_isdigit('0' - 1));
	TEST_ASSERT_EQUAL(1, ft_isdigit('0'));
	TEST_ASSERT_EQUAL(0, ft_isdigit('9' + 1));
	TEST_ASSERT_EQUAL(1, ft_isdigit('9'));
}