#include "tests.h"

void test_ft_strdup(void) {
    char    *expected;
    char    *result;

    expected = strdup("Testando123");
    result = ft_strdup("Testando123");
    TEST_ASSERT_EQUAL_STRING(expected, result);
    free(expected);
    free(result);

    char * s = ft_strdup((char*)"coucou");
	TEST_ASSERT(strcmp(s, "coucou") == '\0');
	TEST_ASSERT_EQUAL(strlen(s), strlen("coucou"));
	
	s = ft_strdup((char*)"");
	TEST_ASSERT(strcmp(s, "") == '\0');
	TEST_ASSERT_EQUAL(strlen(s), 0);
}