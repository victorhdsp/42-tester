#include "tests.h"

void test_ft_strchr(void) {
    char    test[24] = "Eu sou um grande teste\0";
    char    *expected;
    char    *result;

    expected = strchr(test, 's');
    result = ft_strchr(test, 's');
    TEST_ASSERT_EQUAL_STRING(expected, result);

    char    *expected2;
    char    *result2;

    expected2 = strchr(test, 'a');
    result2 = ft_strchr(test, 'a');
    
    TEST_ASSERT_EQUAL_STRING(expected, result);

    char s[] = "tripouille";
	TEST_ASSERT_EQUAL_STRING(ft_strchr(s, 't'), strchr(s, 't'));
	TEST_ASSERT_EQUAL_STRING(ft_strchr(s, 'l'),strchr(s, 'l'));
	TEST_ASSERT_EQUAL_STRING(ft_strchr(s, 'z'), strchr(s, 'z'));
	TEST_ASSERT_EQUAL_STRING(ft_strchr(s, 0), strchr(s, 0));
	TEST_ASSERT_EQUAL_STRING(ft_strchr(s, 't' + 256), strchr(s, 't' + 256));
}