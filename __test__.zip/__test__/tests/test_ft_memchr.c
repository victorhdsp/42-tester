#include "tests.h"

void test_ft_memchr(void) {
    char    test[24] = "Eu sou um grande teste\0";
    char    *expected;
    char    *result;

    expected = memchr(test, 's', 23);
    result = ft_memchr(test, 's', 23);
    TEST_ASSERT_EQUAL_STRING(expected, result);

    char s[] = {0, 1, 2 ,3 ,4 ,5};
	TEST_ASSERT_EQUAL(ft_memchr(s, 0, 0), NULL);
	TEST_ASSERT_EQUAL(ft_memchr(s, 0, 1), s);
	TEST_ASSERT_EQUAL(ft_memchr(s, 2, 3), s + 2);
	TEST_ASSERT_EQUAL(ft_memchr(s, 6, 6), NULL);
	TEST_ASSERT_EQUAL(ft_memchr(s, 2 + 256, 3), s + 2);
}