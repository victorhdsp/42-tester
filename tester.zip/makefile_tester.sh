#!/bin/bash

cd __test__

COMPILADOR="clang -Wall -Wextra -lbsd -g";
HEADER_FOLDER="../repo/"; #Relativo a pasta de testes.
C_FOLDER="../repo/src"; #Relativo a pasta de testes.
UNITY_SRC="./src"; #Relativo a pasta de testes.
TEST_FOLDER="./tests"; #Relativo a pasta de testes.

ALL="unity.o main.o $(ls "$C_FOLDER" | tr "\n" " " | sed -e 's|\.c|\.o|g') $(ls "$TEST_FOLDER" | tr "\n" " " | sed -e 's|\.c|\.o|g')"

(
    echo "test: $ALL";
    echo -e "\t$COMPILADOR -o test $ALL";
    echo "";
    echo "unity.o: $UNITY_SRC/unity.c";
    echo -e "\t$COMPILADOR -c $UNITY_SRC/unity.c -o unity.o";
    echo "";
    echo "main.o: main.c";
    echo -e "\t$COMPILADOR -I $UNITY_SRC -I $HEADER_FOLDER -c main.c -o main.o";
    echo "";
    for C_FILE in $(ls "$C_FOLDER/"); do
        O_FILE=$(echo "$C_FILE" | sed -e 's|\.c|\.o|g')
        echo -e "$O_FILE: $C_FOLDER/$C_FILE";
        echo -e "\t$COMPILADOR -I $HEADER_FOLDER -c $C_FOLDER/$C_FILE -o $O_FILE";
    done
    echo "";
    for C_FILE in $(ls "$TEST_FOLDER/"); do
        O_FILE=$(echo "$C_FILE" | sed -e 's|\.c|\.o|g')
        echo -e "$O_FILE: $TEST_FOLDER/$C_FILE";
        echo -e "\t$COMPILADOR -I $HEADER_FOLDER -I $UNITY_SRC -c $TEST_FOLDER/$C_FILE -o $O_FILE";
    done
    echo "";
    echo "clean:";
    echo -e "\trm -f *.o test";
) > makefile

make
./test