# 42 Tester (MAKEFILE VERSION + UNITY)

## Como utilizar

### Manejamento
O Repositório que vai ser testado como padrão precisa ser colocado com o nome "/repo", dentro dele os headers devem estar em "/headers" e os arquivos em "/src", o compilador usado é o "clang".

Caso você queira mudar basta alterar o nome na variavel dentro do arquivo "makefile_tester.sh".

### Execução
A execução mais simples possível seria:
- ```bash makefile_tester.sh```

Mas eu que tenho amor a minha sanidade mental recomendo usar, executando em tempo real:
- ```watch bash makefile_tester.sh```

## Instalação
Não tem instalação, são arquivos em C, seu computador provavelmente já roda.

basta clonar o repositório, remover o meu ".git" e adicionar o seu repositório dentro.

- ```git clone git@github.com:victorhdsp/42-tester.git```
- ```mkdir <projeto>```
- ```mv makefile_tester/* <projeto>```
- ```rm -rf .git```
- ```cd <projeto>```
- ```git clone git@github.com:<voce><seuprojeto>.git repo```

ou você pode fazer com a interface igual a um humano normal, fica a teu critério.