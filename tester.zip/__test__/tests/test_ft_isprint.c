#include "tests.h"

void test_ft_isprint(void) {
    TEST_ASSERT_EQUAL(1, ft_isprint('c'));
    TEST_ASSERT_EQUAL(1, ft_isprint('1'));
    TEST_ASSERT_EQUAL(1, ft_isprint('-'));
    TEST_ASSERT_EQUAL(1, ft_isprint('B'));
    TEST_ASSERT_EQUAL(0, ft_isprint('\0'));
    TEST_ASSERT_EQUAL(0, ft_isprint(-1));
    TEST_ASSERT_EQUAL(0, ft_isprint(' ' - 1));
	TEST_ASSERT_EQUAL(1, ft_isprint(' '));
	TEST_ASSERT_EQUAL(1, ft_isprint('~' + 1));
	TEST_ASSERT_EQUAL(1, ft_isprint('~'));
}