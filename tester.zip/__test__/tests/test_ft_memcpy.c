#include "tests.h"

void test_ft_memcpy(void) {
    char    expected[10] = "123456789\0";
    char    result[10] = "123456789\0";
    
    memcpy(expected, expected + 2, 5);
    ft_memcpy(result, result + 2, 5);
    TEST_ASSERT_EQUAL_STRING(expected, result);

    char dest[11];
	memset(dest, 'A', 10);
	TEST_ASSERT_EQUAL_STRING(memcpy(dest, "coucou", 0), ft_memcpy(dest, "coucou", 0));
    TEST_ASSERT_EQUAL_STRING(memcpy(dest, "coucou", 6), ft_memcpy(dest, "coucou", 6));
}