#include "tests.h"

void test_ft_atoi(void) {
	char    test1[30] = ("1");
	char    test3[30] = ("--1");
	char    test4[30] = ("++1");
	char    test5[30] = ("+1");
	char    test6[30] = ("-1");
	char    test7[30] = ("0");
	char    test8[30] = ("+42lyon");
	char    test9[30] = ("+101");
    char    test10[30] = ("  +101");
    char    test11[30] = ("   -101");
	char    test12[30] = "-+42";
	char    test13[30] = "+-42";
	char    test14[30] = "+42";
	char    test15[30] = "-42";
	char    test16[30] = "142";
	char    test17[30] = "-142";
    char    test18[5] = "1000";
    char    test19[5] = "-532";
    char    test20[4] = "--42";
    char    test21[11] = "2147483648";
    char    test22[12] = "-2147483648";

    TEST_ASSERT_EQUAL(atoi(test1), ft_atoi(test1));
    TEST_ASSERT_EQUAL(atoi(test3), ft_atoi(test3));
    TEST_ASSERT_EQUAL(atoi(test4), ft_atoi(test4));
    TEST_ASSERT_EQUAL(atoi(test5), ft_atoi(test5));
    TEST_ASSERT_EQUAL(atoi(test6), ft_atoi(test6));
    TEST_ASSERT_EQUAL(atoi(test7), ft_atoi(test7));
    TEST_ASSERT_EQUAL(atoi(test8), ft_atoi(test8));
    TEST_ASSERT_EQUAL(atoi(test9), ft_atoi(test9));
    TEST_ASSERT_EQUAL(atoi(test12), ft_atoi(test12));
    TEST_ASSERT_EQUAL(atoi(test13), ft_atoi(test13));
    TEST_ASSERT_EQUAL(atoi(test14), ft_atoi(test14));
    TEST_ASSERT_EQUAL(atoi(test15), ft_atoi(test15));
    TEST_ASSERT_EQUAL(atoi(test17), ft_atoi(test17));
    TEST_ASSERT_EQUAL(atoi(test18), ft_atoi(test18));
    TEST_ASSERT_EQUAL(atoi(test19), ft_atoi(test19));
    TEST_ASSERT_EQUAL(atoi(test20), ft_atoi(test20));
    TEST_ASSERT_EQUAL(atoi(test21), ft_atoi(test21));
    TEST_ASSERT_EQUAL(atoi(test22), ft_atoi(test22));
}