#include "tests.h"

void test_ft_substr(void) {
    char    *test1;
    char    *test2;

    test1 = ft_substr("0123456789", 3, 7);
    TEST_ASSERT_EQUAL_STRING("3456789", test1);
    test2 = ft_substr("0123456789", 1, 0);
    TEST_ASSERT_EQUAL_STRING("", test2);
    
    char * s = ft_substr("tripouille", 0, 42000);
	TEST_ASSERT_EQUAL_STRING(s, "tripouille");
	TEST_ASSERT(strlen(s) == strlen("tripouille"));

	s = ft_substr("tripouille", 1, 1);
	TEST_ASSERT_EQUAL_STRING(s, "r");
	TEST_ASSERT(strlen(s) == 1);

	s = ft_substr("tripouille", 100, 1);
	TEST_ASSERT_EQUAL_STRING(s, "");
	TEST_ASSERT(strlen(s) == 0);

	char * str = strdup("1");
	s = ft_substr(str, 42, 42000000);
	TEST_ASSERT_EQUAL_STRING(s, "");
	TEST_ASSERT(strlen(s) == 0);

	str = strdup("0123456789");
	s = ft_substr(str, 9, 10);
	TEST_ASSERT_EQUAL_STRING(s, "9");
	TEST_ASSERT(strlen(s) == 1);

	s = ft_substr("42", 0, 0);
	TEST_ASSERT_EQUAL_STRING(s, "");
	TEST_ASSERT(strlen(s) == 0);

	s = ft_substr("BONJOUR LES HARICOTS !", 8, 14);
	TEST_ASSERT_EQUAL_STRING(s, "LES HARICOTS !");
	TEST_ASSERT(strlen(s) == 14);

	s = ft_substr("test", 1, 2);
	TEST_ASSERT_EQUAL_STRING(s, "es");
	TEST_ASSERT(strlen(s) == 2);
}