#include "tests.h"

void test_ft_isascii(void) {
    TEST_ASSERT_EQUAL(1, ft_isascii('c'));
    TEST_ASSERT_EQUAL(1, ft_isascii('1'));
    TEST_ASSERT_EQUAL(1, ft_isascii('-'));
    TEST_ASSERT_EQUAL(1, ft_isascii('B'));
    TEST_ASSERT_EQUAL(1, ft_isascii('\0'));
    TEST_ASSERT_EQUAL(0, ft_isascii(-1));
    TEST_ASSERT_EQUAL(0, ft_isascii(-1));
	TEST_ASSERT_EQUAL(1, ft_isascii(0));
	TEST_ASSERT_EQUAL(0, ft_isascii(128));
	TEST_ASSERT_EQUAL(1, ft_isascii(127));
}