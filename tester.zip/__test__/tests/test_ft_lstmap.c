#include "tests.h"

static void ft_test3(void *c)
{
    (void)c;
}
static void *ft_test4(void *c)
{
    return ("aaaaa");
}
static void * addOne(void * p) {void * r = malloc(sizeof(int)); *(int*)r = *(int*)p + 1; return (r);}

void test_ft_lstmap(void) {
    t_list *lst1;
    t_list *lst2;
    t_list *result;

    lst1 = ft_lstnew((void *)"test1");
    lst2 = ft_lstnew((void *)"test2");
    ft_lstadd_front(&lst1, lst2);
    result = ft_lstmap(lst1, ft_test4, ft_test3);
    TEST_ASSERT_EQUAL_STRING("aaaaa", result->content);

    int tab[] = {0, 1, 2, 3};
	t_list * l =  ft_lstnew(tab);
	for (int i = 1; i < 4; ++i)
		ft_lstadd_back(&l, ft_lstnew(tab + i));
	t_list *m = ft_lstmap(l, addOne, free);
	t_list * tmp = l;
	for (int i = 0; i < 4; ++i)
	{
		TEST_ASSERT_EQUAL(i, *(int*)tmp->content);
		tmp = (t_list *)tmp->next;
	}
	tmp = m;
	for (int i = 0; i < 4; ++i)
	{
		TEST_ASSERT_EQUAL(i + 1, *(int*)tmp->content);
		tmp = (t_list *)tmp->next;
	}
}