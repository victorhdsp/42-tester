#include "tests.h"

void test_ft_strnstr(void) {
    const char	test1[13] = "Foo Bar Baz\0";
    const char	test2[5] = "Bar\0";
    char    *expected;
    char    *result;

    expected = strnstr(test1, test2, 12);
    result = ft_strnstr(test1, test2, 12);
    TEST_ASSERT_EQUAL_STRING(expected, result);

    char haystack[30] = "aaabcabcd";
	char needle[10] = "aabc";
	char *empty = "";
	TEST_ASSERT(ft_strnstr(haystack, needle, 0) == strnstr(haystack, needle, 0));
	TEST_ASSERT(ft_strnstr(haystack, needle, -1) == strnstr(haystack, needle, -1));
	TEST_ASSERT(ft_strnstr(haystack, "a", -1) == strnstr(haystack, "a", -1));
	TEST_ASSERT(ft_strnstr(haystack, "c", -1) == strnstr(haystack, "c", -1));
	TEST_ASSERT(ft_strnstr(empty, "", -1) == strnstr(empty, "", -1));
	TEST_ASSERT(ft_strnstr(empty, "", 0) == strnstr(empty, "", 0));
	TEST_ASSERT(ft_strnstr(empty, "coucou", -1) == strnstr(empty, "coucou", -1));
	TEST_ASSERT(ft_strnstr(haystack, "aaabc", 5) == strnstr(haystack, "aaabc", 5));
	TEST_ASSERT(ft_strnstr(empty, "12345", 5) == strnstr(empty, "12345", 5));
	TEST_ASSERT(ft_strnstr(haystack, "abcd", 9) == strnstr(haystack, "abcd", 9));
	TEST_ASSERT(ft_strnstr(haystack, "cd", 8) == strnstr(haystack, "cd", 8));
	TEST_ASSERT(ft_strnstr(haystack, "a", 1) == strnstr(haystack, "a", 1));
	TEST_ASSERT(ft_strnstr("1", "a", 1) == strnstr("1", "a", 1));
	TEST_ASSERT(ft_strnstr("22", "b", 2) == strnstr("22", "b", 2));
}