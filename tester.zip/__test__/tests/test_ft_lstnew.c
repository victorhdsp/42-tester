#include "tests.h"

void test_ft_lstnew(void) {
    t_list *result;

    result = ft_lstnew((void *)"adoleta");
    TEST_ASSERT_EQUAL_STRING("adoleta", result->content);
    free(result);
}