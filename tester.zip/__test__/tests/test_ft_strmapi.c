#include "tests.h"

char ft_test(unsigned int i, char c)
{
    if (c + i < 127)
        return (c + i);
    return (c);
}
void test_ft_strmapi(void) {
    char *result;
    char *result2;

    result = ft_strmapi("adoleta", ft_test);
    result2 = ft_strmapi("", ft_test);
    TEST_ASSERT_EQUAL_STRING("aeqoiyg", result);
    TEST_ASSERT_EQUAL_STRING("", result2);
    free(result);

    char * s = ft_strmapi("1234", ft_test);
	TEST_ASSERT(strcmp(s, "1357") == '\0');
	TEST_ASSERT_EQUAL(strlen(s), strlen("1357"));

	s = ft_strmapi("", ft_test);
	TEST_ASSERT(strcmp(s, "") == '\0');
    TEST_ASSERT_EQUAL(strlen(s), strlen(""));
}