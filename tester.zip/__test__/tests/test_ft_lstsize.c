#include "tests.h"

void test_ft_lstsize(void) {
    t_list *lst1;
    t_list *lst2;
    t_list *lst3;

    lst1 = ft_lstnew((void *)"test1");
    lst2 = ft_lstnew((void *)"test2");
    lst3 = ft_lstnew((void *)"test3");
    ft_lstadd_front(&lst1, lst2);
    ft_lstadd_front(&lst2, lst3);
    TEST_ASSERT_EQUAL(3, ft_lstsize(lst3));
    
    t_list * l =  NULL;
	TEST_ASSERT_EQUAL(ft_lstsize(l), 0);
	ft_lstadd_front(&l, ft_lstnew((void*)1));
	TEST_ASSERT_EQUAL(ft_lstsize(l), 1);
	ft_lstadd_front(&l, ft_lstnew((void*)2));
	TEST_ASSERT_EQUAL(ft_lstsize(l), 2);
}