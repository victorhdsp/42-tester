#include "tests.h"

void test_ft_strlcat(void) {
    char    test[11] = "1234567890\0";
    char    expected[20] = "ass";
    char    result[20] = "ass";
    unsigned int     expectedInt;
    unsigned int     resultInt;

    expectedInt = strlcat(expected, test, 3);
    resultInt = ft_strlcat(result, test, 3);
    TEST_ASSERT_EQUAL_STRING(expected, result);
    TEST_ASSERT_EQUAL(expectedInt, resultInt);

    char dest[30]; memset(dest, 0, 30);
	char * src = (char *)"AAAAAAAAA";
	dest[0] = 'B';
	TEST_ASSERT_EQUAL(ft_strlcat(dest, src, 0), strlcat(dest, src, 0)); 
	dest[0] = 'B';
	TEST_ASSERT_EQUAL(ft_strlcat(dest, src, 1), strlcat(dest, src, 1));
	memset(dest, 'B', 4);
	TEST_ASSERT_EQUAL(ft_strlcat(dest, src, 3), strlcat(dest, src, 3));
	TEST_ASSERT_EQUAL(ft_strlcat(dest, src, 6), strlcat(dest, src, 6)); 
	memset(dest, 'C', 5);
	TEST_ASSERT_EQUAL(ft_strlcat(dest, src, -1), strlcat(dest, src, -1)); 
	memset(dest, 'C', 15);
	TEST_ASSERT_EQUAL(ft_strlcat(dest, src, 17), strlcat(dest, src, 17)); 
	memset(dest, 0, 30);
	TEST_ASSERT_EQUAL(ft_strlcat(dest, src, 1), strlcat(dest, src, 1)); 
	memset(dest, 0, 30); memset(dest, '1', 10);
	TEST_ASSERT_EQUAL(ft_strlcat(dest, src, 5), strlcat(dest, src, 5)); 
	memset(dest, 0, 30); memset(dest, '1', 10);
	TEST_ASSERT_EQUAL(ft_strlcat(dest, src, 5), strlcat(dest, src, 5)); 
	memset(dest, 0, 30); memset(dest, '1', 10);
	TEST_ASSERT_EQUAL(ft_strlcat(dest, "", 15), strlcat(dest, "", 15)); 
	memset(dest, 0, 30);
	TEST_ASSERT_EQUAL(ft_strlcat(dest, "", 42), strlcat(dest, "", 42)); 
	memset(dest, 0, 30);
	TEST_ASSERT_EQUAL(ft_strlcat(dest, "", 0), strlcat(dest, "", 0)); 
	memset(dest, 0, 30);
	TEST_ASSERT_EQUAL(ft_strlcat(dest, "123", 1), strlcat(dest, "123", 1)); 
	memset(dest, 0, 30);
	TEST_ASSERT_EQUAL(ft_strlcat(dest, "123", 2), strlcat(dest, "123", 2)); 
	memset(dest, 0, 30);
	TEST_ASSERT_EQUAL(ft_strlcat(dest, "123", 3), strlcat(dest, "123", 3)); 
	memset(dest, 0, 30);
	TEST_ASSERT_EQUAL(ft_strlcat(dest, "123", 4), strlcat(dest, "123", 4)); 
	memset(dest, 0, 30);
	TEST_ASSERT_EQUAL(ft_strlcat(dest, "123", 0), strlcat(dest, "123", 0)); 
}