#include "tests.h"

void test_ft_memmove(void) {
    char    expected[10] = "123456789\0";
    char    result[10] = "123456789\0";
    char    expected2[10] = "123456789\0";
    char    result2[10] = "123456789\0";
    
    memmove(expected, expected + 2, 5);
    ft_memmove(result, result + 2, 5);
    TEST_ASSERT_EQUAL_STRING(expected, result);

    memmove(expected2 + 2, expected2, 5);
    ft_memmove(result2 + 2, result2, 5);
    TEST_ASSERT_EQUAL_STRING(expected2, result2);

    char s[] = {65, 66, 67, 68, 69, 0, 45};
	char s0[] = { 0,  0,  0,  0,  0,  0, 0};
	char sCpy[] = {65, 66, 67, 68, 69, 0, 45};
	char sResult[] = {67, 68, 67, 68, 69, 0, 45};
	char sResult2[] = {67, 67, 68, 68, 69, 0, 45};

	TEST_ASSERT(ft_memmove(s0, s, 7) == s0 && !memcmp(s, s0, 7)); //Post 0
	TEST_ASSERT(ft_memmove(s, s + 2, 0) && !memcmp(s, sCpy, 7)); //0 move
	TEST_ASSERT(ft_memmove(s, s + 2, 2) == s && !memcmp(s, sResult, 7)); //forward
	TEST_ASSERT(ft_memmove(sResult + 1, sResult, 2) == sResult + 1 && !memcmp(sResult, sResult2, 7));
}