#include "tests.h"

void test_ft_strtrim(void) {
    char    *test1;
    char    *test2;

    test1 = ft_strtrim("ba01234ab", "ab");
    TEST_ASSERT_EQUAL_STRING("01234", test1);
    test2 = ft_strtrim("", "aa");
    TEST_ASSERT_EQUAL_STRING("", test2);

    char * s = ft_strtrim("   xxxtripouille", " x");
	TEST_ASSERT_EQUAL_STRING(s, "tripouille");
	TEST_ASSERT(ft_strlen(s) == ft_strlen("tripouille"));

	s = ft_strtrim("tripouille   xxx", " x");
	TEST_ASSERT_EQUAL_STRING(s, "tripouille");
	TEST_ASSERT(ft_strlen(s) == ft_strlen("tripouille"));

	s = ft_strtrim("   xxxtripouille   xxx", " x");
	TEST_ASSERT_EQUAL_STRING(s, "tripouille");
	TEST_ASSERT(ft_strlen(s) == ft_strlen("tripouille"));
	
	s = ft_strtrim("   xxx   xxx", " x");
	TEST_ASSERT_EQUAL_STRING(s, "");
	TEST_ASSERT(ft_strlen(s) == 0);

	s = ft_strtrim("", "123");
	TEST_ASSERT_EQUAL_STRING(s, "");
	TEST_ASSERT(ft_strlen(s) == 0);

	s = ft_strtrim("123", "");
	TEST_ASSERT_EQUAL_STRING(s, "123");
	TEST_ASSERT(ft_strlen(s) == 3);

	s = ft_strtrim("", "");
	TEST_ASSERT_EQUAL_STRING(s, "");
	TEST_ASSERT(ft_strlen(s) == 0);
	
	char * t = ft_strtrim("   xxxtripouille", " x");
	t = ft_strtrim("abcdba", "acb");
	TEST_ASSERT_EQUAL_STRING(t, "d");
 	TEST_ASSERT(ft_strlen(t) == 1);
}