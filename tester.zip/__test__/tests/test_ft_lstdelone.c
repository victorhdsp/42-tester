#include "tests.h"

static void ft_test3(void *c)
{
    (void)c;
}
void test_ft_lstdelone(void) {
    t_list *lst1;
    t_list *lst2;

    lst1 = ft_lstnew((void *)1);
    lst2 = ft_lstnew((void *)2);
    ft_lstadd_front(&lst1, lst2);
    TEST_ASSERT_EQUAL(lst1->content, 2);
    ft_lstdelone(lst1, ft_test3);
}