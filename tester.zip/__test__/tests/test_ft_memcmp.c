#include "tests.h"

void test_ft_memcmp(void) {
    char    test1[9] = "abcdefg\0";
    char    test2[9] = "fffffff\0";

    TEST_ASSERT_EQUAL(memcmp(test1, test2, 6), ft_memcmp(test1, test2, 6));

    char s[] = {-128, 0, 127, 0};
	char sCpy[] = {-128, 0, 127, 0};
	char s2[] = {0, 0, 127, 0};
	char s3[] = {0, 0, 42, 0};
	TEST_ASSERT_EQUAL(memcmp(s, sCpy, 4), ft_memcmp(s, sCpy, 4));
	TEST_ASSERT_EQUAL(memcmp(s, s2, 0), ft_memcmp(s, s2, 0));
	TEST_ASSERT_EQUAL(memcmp(s, s2, 1), ft_memcmp(s, s2, 1));
	TEST_ASSERT_EQUAL(memcmp(s2, s, 1), ft_memcmp(s2, s, 1));
	TEST_ASSERT_EQUAL(memcmp(s2, s3, 4), ft_memcmp(s2, s3, 4));
    TEST_ASSERT_EQUAL(memcmp(s2, s3, 10), ft_memcmp(s2, s3, 10));
}