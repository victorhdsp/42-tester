#include "tests.h"

void test_ft_strjoin(void) {
    char    *test1;
    char    *test2;

    test1 = ft_strjoin("01234", "56789");
    TEST_ASSERT_EQUAL_STRING("0123456789", test1);
    test2 = ft_strjoin("", "");
    TEST_ASSERT_EQUAL_STRING("", test2);
    free(test1);
    free(test2);

    char * s = ft_strjoin("tripouille", "42");
	TEST_ASSERT(strcmp(s, "tripouille42") == '\0');
	TEST_ASSERT_EQUAL(strlen(s), strlen("tripouille") + strlen("42"));

	s = ft_strjoin("", "42");
	TEST_ASSERT(!strcmp(s, "42"));
	TEST_ASSERT_EQUAL(strlen(s), strlen("") + strlen("42"));

	s = ft_strjoin("42", "");
	TEST_ASSERT(!strcmp(s, "42"));
	TEST_ASSERT_EQUAL(strlen(s), strlen("42") + strlen(""));

	s = ft_strjoin("", "");
	TEST_ASSERT_EQUAL_STRING(s, "");
	TEST_ASSERT_EQUAL(strlen(s), 0);
}