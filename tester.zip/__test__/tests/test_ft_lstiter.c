#include "tests.h"

static void ft_test3(void *c)
{
    (void)c;
}
void test_ft_lstiter(void) {
    t_list *lst1;
    t_list *lst2;

    lst1 = ft_lstnew((void *)"test1");
    lst2 = ft_lstnew((void *)"test2");
    ft_lstadd_front(&lst1, lst2);
    ft_lstiter(lst1, ft_test3);
}