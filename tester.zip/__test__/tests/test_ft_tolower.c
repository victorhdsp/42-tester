#include "tests.h"

void test_ft_tolower(void) {
    char    test1 = 'a';
    char    test2 = 'B';
    char    test3 = '3';
    char    test4 = '-';

    TEST_ASSERT_EQUAL('a', ft_tolower(test1));
    TEST_ASSERT_EQUAL('b', ft_tolower(test2));
    TEST_ASSERT_EQUAL('3', ft_tolower(test3));
    TEST_ASSERT_EQUAL('-', ft_tolower(test4));

    TEST_ASSERT_EQUAL(ft_tolower('A' - 1), 'A' - 1);
	TEST_ASSERT_EQUAL(ft_tolower('A'), 'a');
	TEST_ASSERT_EQUAL(ft_tolower('Z' + 1), 'Z' + 1);
	TEST_ASSERT_EQUAL(ft_tolower('Z'), 'z');
}