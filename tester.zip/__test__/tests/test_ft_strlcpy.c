#include "tests.h"

void test_ft_strlcpy(void) {
    char    test[11] = "1234567890\0";
    char    expected[10];
    char    result[10];
    unsigned int     expectedInt;
    unsigned int     resultInt;

    expectedInt = strlcpy(expected, test, 8);
    resultInt = ft_strlcpy(result, test, 8);
    TEST_ASSERT_EQUAL_STRING(expected, result);
    TEST_ASSERT_EQUAL(expectedInt, resultInt);

    char src[] = "coucou";
	char dest[10]; 
    memset(dest, 'A', 10);
	TEST_ASSERT(ft_strlcpy(dest, src, 0) == strlen(src));
    TEST_ASSERT(dest[0] == 'A');

	TEST_ASSERT(ft_strlcpy(dest, src, 1) == strlen(src));
    TEST_ASSERT(dest[0] == 0);
    TEST_ASSERT(dest[1] == 'A'); 

	TEST_ASSERT(ft_strlcpy(dest, src, 2) == strlen(src));
    TEST_ASSERT(dest[0] == 'c');
    TEST_ASSERT(dest[1] == 0);
    TEST_ASSERT(dest[2] == 'A'); 

	TEST_ASSERT(ft_strlcpy(dest, src, -1) == strlen(src));
    TEST_ASSERT(strcmp(src, dest) == '\0');
    TEST_ASSERT(dest[strlen(src) + 1] == 'A'); 
    memset(dest, 'A', 10);

	TEST_ASSERT(ft_strlcpy(dest, src, 6) == strlen(src));
    TEST_ASSERT(memcmp(src, dest, 5) == '\0');
    TEST_ASSERT(dest[5] == 0); 
    memset(dest, 'A', 10);

	TEST_ASSERT(ft_strlcpy(dest, src, 7) == strlen(src));
    TEST_ASSERT(memcmp(src, dest, 7) == '\0'); 
    memset(dest, 'A', 10);

	TEST_ASSERT(ft_strlcpy(dest, src, 8) == strlen(src));
    TEST_ASSERT(memcmp(src, dest, 7) == '\0'); 
    memset(dest, 'A', 10);

	TEST_ASSERT(ft_strlcpy(dest, "", 42) == 0);
    TEST_ASSERT(memcmp("", dest, 1) == '\0'); 
    memset(dest, 0, 10);

	TEST_ASSERT(ft_strlcpy(dest, "1", 0) == 1);
    TEST_ASSERT(dest[0] == 0); 
    memset(dest, 'A', 10);
}