#include "tests.h"

void test_ft_memset(void) {
    char    expected[10];
    char    result[10];

    TEST_ASSERT_EQUAL_STRING((char *)memset(expected, 'A', 9), (char *)ft_memset(result, 'A', 9));
    TEST_ASSERT_EQUAL_STRING(expected, result);

    char tab[100];
	memset(tab, 0, 100);
	ft_memset(tab, 'A', 0);
	TEST_ASSERT(tab[0] == 0);
	ft_memset(tab, 'A', 42);
	int i = 0;
	for (; i < 100 && tab[i] == 'A'; ++i)
		;
	TEST_ASSERT(i == 42 && tab[42] == 0);
}