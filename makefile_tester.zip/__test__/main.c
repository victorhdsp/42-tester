#include "unity.h"
#include "test.h"

void setUp(void) { }

void tearDown(void) { }

void test_ft_test(void) {
    TEST_ASSERT_EQUAL(3, ft_test());
}

void test_ft_test2(void) {
    TEST_ASSERT_EQUAL('c', ft_test2());
}

int main(void) {
    UNITY_BEGIN();
    RUN_TEST(test_ft_test);
    RUN_TEST(test_ft_test2);
    return UNITY_END();
}