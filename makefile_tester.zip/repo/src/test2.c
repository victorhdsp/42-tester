#include "test.h"

char    ft_test2(void)
{
    return ('c');
}