#include "test.h"

int    ft_test(void)
{
    return (3);
}
