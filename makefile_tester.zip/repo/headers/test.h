#ifndef TEST_H
#define TEST_H

#include <unistd.h>

int    ft_test(void);
char   ft_test2(void);

#endif